﻿import pygame
from pygame.locals import *
import random
pygame.init()

#nom de la fenêtre
pygame.display.set_caption("Space Adventure")

fenetre = pygame.display.set_mode((1280,720))
background = pygame.image.load("Images/fond_niveau.png").convert_alpha()
background = pygame.transform.scale(background,(1280,720))
banniere=pygame.image.load("Images/banner.png")
banniere_rect=banniere.get_rect()

boutton_demarrer=pygame.image.load("Images/boutton.png")
boutton_demarrer_rect=boutton_demarrer.get_rect()

fenetre.blit(background,(0,0))
pygame.display.flip()


#class qui represente le jeu
class Jeu:

    def __init__(self):
        self.start = False
        #création du joueur
        self.tout_les_joueurs = pygame.sprite.Group()
        self.player =Joueur(self)
        self.tout_les_joueurs.add(self.player)
        #groupe de montre
        self.tout_les_monstres = pygame.sprite.Group()
        self.pressed = {}

    def demarrer(self):
        self.start=True
        self.apparition_monstre()

    def game_over(self):
        #remettre le jeu à zero
        self.tout_les_monstres=pygame.sprite.Group()
        self.player.vie= self.player.maxVie
        self.start=False

    def verif_collision(self, sprite, group):
        return pygame.sprite.spritecollide(sprite, group, False, pygame.sprite.collide_mask)


    def apparition_monstre(self):
        monstre= Monstre(self)
        self.tout_les_monstres.add(monstre)





#class qui représente le joueur et ses caractéristiques
class Joueur(pygame.sprite.Sprite):

    def __init__(self, Jeu):
        super().__init__()
        self.jeu = Jeu
        self.vie=100
        self.maxVie=100
        self.vitesse=5
        self.degat=10
        self.projectiles=pygame.sprite.Group()
        self.image=pygame.image.load("Images/ghost.png")
        self.image=pygame.transform.scale(self.image,(180,180))
        self.rect = self.image.get_rect()
        self.rect.x=300
        self.rect.y=500

    def dommage(self, pts_vie):
        if self.vie - pts_vie> pts_vie:
            self.vie -= pts_vie
        else:
            #joueur mort
            self.jeu.game_over()

    def maj_vie_barre(self, surface):
        #creation de la barre de vie
        pygame.draw.rect(surface, (60,63,60), [self.rect.x + 35, self.rect.y -20, self.maxVie, 5])
        pygame.draw.rect(surface, (111, 210, 46), [self.rect.x + 35, self.rect.y -20, self.vie, 5])


    def launch_projectile(self):
        #creer la projection de la classe projectile
        self.projectiles.add(Projectiles_Player(self))

    def move_right(self):
        # si le perso ne touche pas un monstre
        if not self.jeu.verif_collision(self, self.jeu.tout_les_monstres):
            self.rect.x += self.vitesse

    def move_left(self):
        self.rect.x -= self.vitesse



class Projectiles_Player(pygame.sprite.Sprite):

    def __init__(self, player):
        super().__init__()
        self.velocity = 5
        self.player=player
        self.image=pygame.image.load("Images/projectile.png")
        self.rect=self.image.get_rect()
        self.rect.x=player.rect.x
        self.rect.y=player.rect.y

    def move(self):
        self.rect.x+=self.velocity
        for monstre in self.player.jeu.verif_collision(self,self.player.jeu.tout_les_monstres):
            projectile.kill()
            #mettre les degats
            monstre.dommage(self.player.degat)

#class pour gérer les monstres
class Monstre(pygame.sprite.Sprite):

    def __init__(self,Jeu):
        super().__init__()
        self.jeu = Jeu
        self.vie = 100
        self.vie_max = 100
        self.atk = 0.2
        self.vitesse = 1
        self.image = pygame.image.load('Images/squid.png')
        self.image =pygame.transform.scale(self.image,(180,180))
        self.rect = self.image.get_rect()
        self.rect.x=1000
        self.rect.y=500

    def dommage(self, pts_vie):
        #mettre les degat
        self.vie-=pts_vie


        #verif pts-de-vie
        if self.vie <= 0:
            liste_perso=['squid','robot','tchoped']
            #respawn
            self.rect.x=1000+random.randint(0,300)
            self.image=pygame.image.load('Images/'+liste_perso[random.randint(0,2)]+'.png')
            self.image =pygame.transform.scale(self.image,(180,180))
            self.vie =self.vie_max
            self.vitesse= random.randint(1,3)

    def maj_vie_barre(self, surface):
        #creation de la barre de vie
        pygame.draw.rect(surface, (60,63,60), [self.rect.x + 35, self.rect.y -20, self.vie_max, 5])
        pygame.draw.rect(surface, (111, 210, 46), [self.rect.x + 35, self.rect.y -20, self.vie, 5])


    def avancer(self):
        #verif si y a un joueur
        if not self.jeu.verif_collision(self, self.jeu.tout_les_joueurs):
            self.rect.x = self.rect.x - self.vitesse
        #verif si le monstre touche le joueur
        else:
            self.jeu.player.dommage(self.atk)





#nom de la fenêtre
pygame.display.set_caption("Space Adventure")

fenetre = pygame.display.set_mode((1280,720))
background = pygame.image.load("Images/fond_niveau.png").convert_alpha()
background = pygame.transform.scale(background,(1280,720))

fenetre.blit(background,(0,0))
pygame.display.flip()


#chargement du jeu
jeu=Jeu()


#lancement de la boucle
jouer=True

while jouer:

    #fenetre du jeu
    fenetre.blit(background,(0,0))

    if jeu.start:
        #image du joueur
        fenetre.blit(jeu.player.image, jeu.player.rect)

        #actualise la barre du joueur
        jeu.player.maj_vie_barre(fenetre)

        #fluidification
        if jeu.pressed.get(pygame.K_RIGHT) and jeu.player.rect.x!=1170:
            jeu.player.move_right()
        elif jeu.pressed.get(pygame.K_LEFT) and jeu.player.rect.x!=-70:
            jeu.player.move_left()

        #deplacement projectiles
        for projectile in jeu.player.projectiles:
            projectile.move()
            if projectile.rect.x>1170:
                projectile.kill()

        #faire avancer tout les monstre
        for monstre in jeu.tout_les_monstres:
            monstre.avancer()
            monstre.maj_vie_barre(fenetre)

        #afficher les projectiles du joueur
        jeu.player.projectiles.draw(fenetre)

        #afficher les monstres
        jeu.tout_les_monstres.draw(fenetre)
    else:
        fenetre.blit(banniere,(0,0))
        fenetre.blit(boutton_demarrer,(0,0))


    pygame.display.flip()


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            jouer = False
            pygame.quit()

        elif event.type == pygame.KEYDOWN:
            jeu.pressed[event.key]=True

            if event.key == pygame.K_SPACE:
                jeu.player.launch_projectile()


        elif event.type == pygame.KEYUP:
            jeu.pressed[event.key]=False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if boutton_demarrer_rect.collidepoint(event.pos):
                jeu.demarrer()


